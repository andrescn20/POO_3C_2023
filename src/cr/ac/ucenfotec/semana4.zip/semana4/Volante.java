package cr.ac.ucenfotec.semana4;

public class Volante {
}
