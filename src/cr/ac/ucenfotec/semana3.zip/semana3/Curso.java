//Definición del paquete al que pertenece
package cr.ac.ucenfotec.semana3;


//Clase curso que utilizamos para corerr el ejemplo.
public class Curso {
    public static void main(String[] args) {
        Estudiante estudiante1 = new Estudiante("Juan", 21, "123123-123123");
        Estudiante estudiante2 = new Estudiante();
        Estudiante estudiante3 = new Estudiante("Matias");
        System.out.println(estudiante1.nombre+ " " + estudiante1.edad + estudiante1.cedula);
        System.out.println(estudiante2.toString());



    }
}
